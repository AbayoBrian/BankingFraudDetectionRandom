from flask import Flask, request, jsonify
import pickle
import pandas as pd

app = Flask(__name__)

# Load the model
with open("model.pkl", "rb") as file:
    model = pickle.load(file)

@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from the request
    data = request.get_json()

    # Convert input data into a DataFrame
    input_data = pd.DataFrame(data)

    # Ensure correct column order
    input_data = input_data[['type', 'amount', 'payerdebited', 'recievercredited']]

    # Make predictions
    predictions = model.predict(input_data)
    probabilities = model.predict_proba(input_data)

    # Return predictions and probabilities as JSON
    return jsonify({
        'predictions': predictions.tolist(),
        'probabilities': probabilities.tolist()
    })

if __name__ == '__main__':
    app.run(debug=True)